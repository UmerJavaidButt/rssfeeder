<?php $__env->startSection('content'); ?>
<section class="login-page container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-10 col-lg-6 col-xs-12">
            <div class="card login-card card-block">
                <div class="card-body">
                    <div class="auth-box">
                    <?php if(session('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                            <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="text-center">
                                <h3 class=" text-center txt-primary">Welcome!</h3>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="text-center txt-primary">
                                        Sign In
                                    </h3>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group row">
                                <!-- <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" onfocus="this.value=''" placeholder="Enter Email Address" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <!-- <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" onfocus="this.value=''" placeholder="Enter Password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row m-t-25 text-left">
                                <div class="col-sm-5 col-xs-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="remember">
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-xs-12 forgot_password">
                                <div class="form-check">
                                    <a class="btn btn-link forgot_password" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row m-t-30">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-md btn-block text-center mb-20">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>