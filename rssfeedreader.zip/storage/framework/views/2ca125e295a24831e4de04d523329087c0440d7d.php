<html lang="en">

<head>
    <title>Flat Able - Premium Admin Template by Phoenixcoded</title>
    <!-- HTML5 Shim and Respond.js IE9 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Phoenixcoded">
    <meta name="keywords" content="flat ui, admin , Flat ui, Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
    <meta name="author" content="Phoenixcoded">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sidebar/themify-icons.css')); ?>">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sidebar/icofont.css')); ?>">

    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sidebar/style.css')); ?>">
    <!-- color .css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sidebar/color-1.css')); ?>" id="color"/>
   </head>

<body>

<nav class="navbar header-navbar">
    <div class="navbar-wrapper">
        <div class="navbar-logo">
            <a class="mobile-menu" id="mobile-collapse" href="#!">
            	<i class="ti-menu"></i>
            </a>
        </div>
    </div>
</nav>

<div class="main-menu">
    <div class="main-menu-header">
        <img class="img-40" src="<?php echo e(asset('images/user.png')); ?>" alt="User-Profile-Image">
        <div class="user-details">
            <span>John Doe</span>
            <span id="more-details">UX Designer<i class="ti-angle-down"></i></span>
        </div>
    </div>

    <div class="main-menu-content">
        <ul class="main-navigation">
	        <li class="nav-title" data-i18n="nav.category.navigation">
	            <i class="ti-line-dashed"></i>
	            <span>Navigation</span>
	        </li>
            <li class="nav-item single-item">
                
            </li>
       </ul>
    </div>
</div>

<div class="main-body">
    <div class="page-wrapper">
        <div class="page-header">
    	    <div class="page-header-title">
                <h4>Project Dashboard</h4>
            </div>
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.html">
                            //
                        </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Project</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="page-body">
            <div class="row">
                <!-- Documents card start -->
                <div class="col-md-12 col-xl-12">
                    <div class="card client-blocks dark-primary-border">
                        <div class="card-block">
                            <h5>New Documents</h5>
                            <ul>
                                <li>
                                    //
                                </li>
                                <li class="text-right">
                                    133
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="<?php echo e(asset('js/sidebar/jquery-ui.min.js')); ?>" defer></script>

<!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('js/sidebar/jquery.slimscroll.js')); ?>"></script>

<!-- Custom js -->
<script src="<?php echo e(asset('js/sidebar/scsript.js')); ?>" defer></script>


</body>
</html>