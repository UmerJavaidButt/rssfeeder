<?php $__env->startSection('content'); ?>
<section class="register-page container">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-10 col-lg-6">
            <div class="card register-card card-block">
                <div class="card-body">
                    <div class="auth-box">   
                            <?php if(session('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                            <?php endif; ?> 
                        <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="text-center txt-primary">
                                        Sign Up
                                    </h3>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group row">
                                <!-- <label for="name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Name')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="name" type="text" placeholder="Enter Full Name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <!-- <label for="email" class="col-md-2 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="email" type="email" placeholder="Enter Email Address" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <!-- <label for="password" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Password')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="password" type="password" placeholder="Enter Password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <!-- <label for="password-confirm" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label> -->

                                <div class="col-md-12">
                                    <input id="password-confirm" type="password" placeholder="Confirm Password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>

                            <div class="form-group row m-t-30">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-block mb-10">
                                        <?php echo e(__('Register')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>